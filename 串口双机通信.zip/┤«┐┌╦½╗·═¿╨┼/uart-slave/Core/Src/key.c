#include "key.h"

uint8_t Key_Scan(void)
{
    uint8_t KeyNum;
    if(HAL_GPIO_ReadPin(key1_GPIO_Port,key1_Pin)==GPIO_PIN_SET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key1_GPIO_Port,key1_Pin)==GPIO_PIN_SET);
        KeyNum=1;
    }
    if(HAL_GPIO_ReadPin(key2_GPIO_Port,key2_Pin)==GPIO_PIN_SET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key2_GPIO_Port,key2_Pin)==GPIO_PIN_SET);
        KeyNum=2;
    }
    return KeyNum;
}
