#ifndef _LED__H_
#define _LED__H_ 

#include "main.h"
#include "gpio.h"

extern void LED_K(uint8_t key);
extern void mcu_led_start(void);
void LED1(uint8_t k);
void LED2(uint8_t k);
void LED3(uint8_t k);
void LED4(uint8_t k);
void LED5(uint8_t k);
void LED6(uint8_t k);
void LED7(uint8_t k);
void LED8(uint8_t k);
void LED1_Toggle(void);
void LED2_Toggle(void);
void led_water(void);

#endif
