#ifndef __KEY_H__
#define __KEY_H__ 

#include "main.h"
#include "gpio.h"
uint8_t Key_Scan(void);

#endif
