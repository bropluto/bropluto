#include "led.h"


void LED_K(uint8_t key)
{
	HAL_GPIO_WritePin(GPIOC,LED1_Pin|LED2_Pin|LED3_Pin|LED4_Pin|LED5_Pin|LED6_Pin|LED7_Pin|LED8_Pin,(GPIO_PinState)key);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void mcu_led_start(void)
{
	LED1(0);
	HAL_Delay(500);
	LED2(0);
	HAL_Delay(500);
	LED1(1);
	HAL_Delay(500);
	LED2(1);
	HAL_Delay(500);
}

void LED1(uint8_t k)
{
	HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED2(uint8_t k)
{
	HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}
void LED3(uint8_t k)
{
	HAL_GPIO_WritePin(LED3_GPIO_Port,LED3_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED4(uint8_t k)
{
	HAL_GPIO_WritePin(LED4_GPIO_Port,LED4_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED5(uint8_t k)
{
	HAL_GPIO_WritePin(LED5_GPIO_Port,LED5_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED6(uint8_t k)
{
	HAL_GPIO_WritePin(LED6_GPIO_Port,LED6_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED7(uint8_t k)
{
	HAL_GPIO_WritePin(LED7_GPIO_Port,LED7_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED8(uint8_t k)
{
	HAL_GPIO_WritePin(LED8_GPIO_Port,LED8_Pin,(GPIO_PinState)k);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED1_Toggle(void)
{
	HAL_GPIO_TogglePin(LED1_GPIO_Port,LED1_Pin);
//	LED1(0);
//	HAL_Delay(500);
//	LED1(1);
//	HAL_Delay(500);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}

void LED2_Toggle(void)
{
	HAL_GPIO_TogglePin(LED2_GPIO_Port,LED2_Pin);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PD2_GPIO_Port,PD2_Pin,GPIO_PIN_SET);
}
void led_water(void)
{
    LED1(0);
    HAL_Delay(50);
    LED1(1);
    LED2(0);
    HAL_Delay(50);
    LED2(1);
    LED3(0);
    HAL_Delay(50);
    LED3(1);
    LED4(0);
    HAL_Delay(50);
    LED4(1);
    LED5(0);
    HAL_Delay(50);
    LED5(1);
    LED6(0);
    HAL_Delay(50);
    LED6(1);
    LED7(0);
    HAL_Delay(50);
    LED7(1);
    LED8(0);
    HAL_Delay(50);
    LED8(1);
}


