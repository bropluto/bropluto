#include "key.h"

uint8_t Key_Scan(void)
{
    uint8_t KeyNum;
    if(HAL_GPIO_ReadPin(key1_GPIO_Port,key1_Pin)==GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key1_GPIO_Port,key1_Pin)==GPIO_PIN_RESET);
        KeyNum=1;
    }
    if(HAL_GPIO_ReadPin(key2_GPIO_Port,key2_Pin)==GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key2_GPIO_Port,key2_Pin)==GPIO_PIN_RESET);
        KeyNum=2;
    }
    if(HAL_GPIO_ReadPin(key3_GPIO_Port,key3_Pin)==GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key3_GPIO_Port,key3_Pin)==GPIO_PIN_RESET);
        KeyNum=3;
    }
    if(HAL_GPIO_ReadPin(key4_GPIO_Port,key4_Pin)==GPIO_PIN_RESET)
    {
        HAL_Delay(20);
        while(HAL_GPIO_ReadPin(key4_GPIO_Port,key4_Pin)==GPIO_PIN_RESET);
        KeyNum=4;
    }
    return KeyNum;
}
